/* =========================================================
   Герои Dominion Era — гайд по классам, контрпикам, связкам
   Логика: калькулятор контрпиков, навигация
   ========================================================= */
(function () {
  'use strict';

  /* =======================================================
     1. КАЛЬКУЛЯТОР КОНТРПИКОВ ПО ТИПУ УГРОЗЫ
     Не привязан к конкретным именам героев (баланс меняется
     чаще, чем стоит жёстко зашивать в код) — вместо этого
     даёт направление поиска: какой класс и какой тип эффекта
     нужен против конкретной угрозы.
     ======================================================= */

  var THREATS = {
    control: {
      advice: 'Ищите героев с иммунитетом к конкретному эффекту контроля ' +
        'или со снятием негативных статусов с союзников до того, как эффект ' +
        'успеет сработать повторно.',
      classes: ['Контроль', 'Поддержка']
    },
    heal: {
      advice: 'Нужен эффект анти-хила — снижение или блокировка лечения. ' +
        'Флаг Упадка тоже неплохо помогает против команд, завязанных на ' +
        'постоянное восстановление здоровья.',
      classes: ['Контроль', 'Целитель']
    },
    crit: {
      advice: 'Герои, наказывающие противника за критический удар, ' +
        'превращают ставку врага на крит в его же слабость. Чем чаще враг ' +
        'критует — тем больнее получает в ответ.',
      classes: ['Поддержка', 'Маг']
    },
    shield: {
      advice: 'Обычный урон бесполезен против неуязвимости и несъёмных ' +
        'щитов — нужны эффекты игнорирования щита или снятия неуязвимости, ' +
        'а не просто рост силы атаки.',
      classes: ['Воин', 'Стрелок']
    },
    displace: {
      advice: 'Возьмите героя, защищающего союзников от смещения ' +
        '(отбрасывания или притягивания) — постоянный сброс позиции ' +
        'разваливает построение сильнее прямого урона.',
      classes: ['Танк', 'Поддержка']
    },
    magic: {
      advice: 'Против высокого магического урона важны магическая защита ' +
        'и герои с уменьшением магического урона по команде. Танк с упором ' +
        'на магическую защиту держит удар лучше, чем просто высокое здоровье.',
      classes: ['Танк', 'Поддержка']
    },
    physical: {
      advice: 'Против высокого физического урона важны броня и уклонение. ' +
        'Танк с упором на броню и герои со снижением физического урона ' +
        'команде нейтрализуют бёрст-состав быстрее, чем встречный урон.',
      classes: ['Танк', 'Целитель']
    }
  };

  function initCounterCalculator() {
    var widget = document.getElementById('counterWidget');
    if (!widget) return;

    var select = document.getElementById('inpThreat');
    var adviceBox = document.getElementById('counterAdvice');
    var classesBox = document.getElementById('counterClasses');

    function render() {
      var threat = THREATS[select.value];
      if (!threat) return;

      adviceBox.textContent = threat.advice;

      classesBox.innerHTML = '';
      threat.classes.forEach(function (label) {
        var chip = document.createElement('span');
        chip.className = 'tag';
        chip.textContent = label;
        classesBox.appendChild(chip);
      });
    }

    select.addEventListener('change', render);
    render();
  }

  /* =======================================================
     2. НАВИГАЦИЯ
     ======================================================= */

  function initNav() {
    var toggle  = document.getElementById('navToggle');
    var sidebar = document.getElementById('sidebar');
    if (!toggle || !sidebar) return;

    toggle.addEventListener('click', function () {
      var open = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    sidebar.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        if (window.innerWidth <= 1024) {
          sidebar.classList.remove('open');
          toggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    document.addEventListener('click', function (e) {
      if (window.innerWidth > 1024) return;
      if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
        sidebar.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  function initScrollSpy() {
    var links = Array.prototype.slice.call(
      document.querySelectorAll('#toc a[href^="#"]')
    );
    if (!links.length) return;

    var sections = links.map(function (a) {
      return document.querySelector(a.getAttribute('href'));
    }).filter(Boolean);

    function update() {
      var pos = window.scrollY + 120;
      var current = sections[0];

      for (var i = 0; i < sections.length; i++) {
        if (sections[i].offsetTop <= pos) current = sections[i];
      }

      links.forEach(function (a) {
        var on = a.getAttribute('href') === '#' + current.id;
        a.classList.toggle('active', on);
      });
    }

    var ticking = false;
    window.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        update();
        ticking = false;
      });
    }, { passive: true });

    update();
  }

  function initToTop() {
    var btn = document.getElementById('toTop');
    if (!btn) return;

    window.addEventListener('scroll', function () {
      btn.classList.toggle('show', window.scrollY > 600);
    }, { passive: true });

    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* =======================================================
     3. СТАРТ
     ======================================================= */

  function init() {
    initCounterCalculator();
    initNav();
    initScrollSpy();
    initToTop();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Экспорт для отладки в консоли
  window.HeroCounter = {
    THREATS: THREATS
  };
})();
