/* =========================================================
   Fall of the Veil (Алекто) — F2P гайд
   Логика: калькулятор мастерской, навигация, графики
   ========================================================= */
(function () {
  'use strict';

  /* =======================================================
     1. ИГРОВЫЕ ДАННЫЕ
     Источник: h-w.fun/en/fall-of-the-veil (таблицы стоимости)

     Примечание: экономика мастерской у Алекто и Валдура
     идентична — те же таблицы стоимости и те же награды глав.
     Отличаются только названия боссов и набор артефактов.
     ======================================================= */

  // Стоимость перехода на уровень L (в кристаллах энергии)
  var TOME_STEP = {
    2: 10, 3: 20, 4: 30, 5: 40, 6: 50, 7: 60, 8: 70, 9: 80,
    10: 80, 11: 80, 12: 80, 13: 80, 14: 80, 15: 80
  };

  var GRAIL_STEP = {
    2: 10, 3: 20, 4: 30, 5: 40, 6: 50, 7: 60, 8: 70, 9: 80, 10: 90,
    11: 100, 12: 100, 13: 100, 14: 100, 15: 100, 16: 100, 17: 100, 18: 100
  };

  // Бонусные монеты при прокачке Тома (не зависят от уровня Тома)
  var TOME_BONUS = {
    2: 1000, 3: 4000, 4: 9000, 5: 16000, 6: 25000, 7: 36000, 8: 49000,
    9: 64000, 10: 72000, 11: 80000, 12: 88000, 13: 96000, 14: 104000, 15: 112000
  };

  // Главы: требуемый уровень Амулета, стоимость в кристаллах (накопительно),
  // накопительные награды
  var CHAPTERS = {
    1: { amuletLvl: 1,  amuletCost: 0,   coins: 10000,  sapph: 1,
         name: 'Спуск во тьму',      boss: 'Край рассвета' },
    2: { amuletLvl: 1,  amuletCost: 0,   coins: 30000,  sapph: 3,
         name: 'Коридор легенд',     boss: 'Сердце чащи' },
    3: { amuletLvl: 5,  amuletCost: 50,  coins: 50000,  sapph: 5,
         name: 'Плато рассвета',     boss: 'Пепельная тропа' },
    4: { amuletLvl: 10, amuletCost: 160, coins: 70000,  sapph: 7,
         name: 'Перекрёсток',        boss: 'Голос руин' },
    5: { amuletLvl: 15, amuletCost: 320, coins: 120000, sapph: 17,
         name: 'Корни и воля',       boss: 'Безмолвный рубеж' },
    6: { amuletLvl: 20, amuletCost: 530, coins: 170000, sapph: 27,
         name: 'Безумная баллада',   boss: 'Эхо машины' },
    7: { amuletLvl: 25, amuletCost: 790, coins: 220000, sapph: 37,
         name: 'Волна бед',          boss: 'Шёпот корней' }
  };

  var PULL_BASE   = 2800; // базовая цена крутки в Алтаре судьбы
  var JACKPOT     = 0.10; // шанс на сапфировый медальон
  var STONES_PULL = 15;   // осколков за неудачную крутку

  var STARS = [
    { star: 1, need: 30 },   { star: 2, need: 80 },
    { star: 3, need: 230 },  { star: 4, need: 730 },
    { star: 5, need: 1630 }, { star: 6, need: 3130 }
  ];

  /* =======================================================
     2. РАСЧЁТЫ
     ======================================================= */

  // Накопительная стоимость прокачки до уровня lvl
  function cumulativeCost(stepTable, lvl) {
    var total = 0;
    for (var L = 2; L <= lvl; L++) {
      total += stepTable[L] || 0;
    }
    return total;
  }

  /**
   * Основной расчёт исхода события.
   *
   * Ключевая механика: бонус Тома капает и при прокачке реликвий тоже.
   * Поэтому кристаллы, вложенные в Амулет и Грааль, тоже приносят
   * 100 × (уровень Тома) монет каждый.
   */
  function simulate(budget, tomeLvl, grailLvl, chapter) {
    var ch = CHAPTERS[chapter];
    if (!ch) return null;

    var tomeCost   = cumulativeCost(TOME_STEP, tomeLvl);
    var grailCost  = cumulativeCost(GRAIL_STEP, grailLvl);
    var amuletCost = ch.amuletCost;

    var spent = tomeCost + grailCost + amuletCost;
    if (spent > budget) {
      return { ok: false, spent: spent, budget: budget, short: spent - budget };
    }

    var coins = 0;

    // (а) бонусы за сами уровни Тома
    for (var L = 2; L <= tomeLvl; L++) {
      coins += TOME_BONUS[L] || 0;
    }

    // (б) бонус Тома с кристаллов, вложенных в Амулет и Грааль.
    // Считаем, что Том качается первым, поэтому бонус идёт по финальному уровню.
    coins += (amuletCost + grailCost) * 100 * tomeLvl;

    // (в) конверсия остатка кристаллов в монеты
    var left = budget - spent;
    var rate = 500 + 100 * tomeLvl;
    coins += left * rate;

    // (г) награды за пройденные главы
    coins += ch.coins;

    // Крутки
    var pullCost = PULL_BASE - 100 * grailLvl;
    var pulls    = coins / pullCost;

    var stones = pulls * (1 - JACKPOT) * STONES_PULL;
    var sapph  = ch.sapph + pulls * JACKPOT;

    return {
      ok: true,
      spent: spent,
      left: left,
      rate: rate,
      coins: Math.round(coins),
      pullCost: pullCost,
      pulls: pulls,
      stones: Math.round(stones),
      sapph: Math.round(sapph),
      tomeCost: tomeCost,
      grailCost: grailCost,
      amuletCost: amuletCost,
      amuletLvl: ch.amuletLvl,
      chapterName: ch.name,
      chapterBoss: ch.boss
    };
  }

  // Сколько звёзд даёт указанное количество осколков
  function starsFor(stones) {
    var result = 0;
    for (var i = 0; i < STARS.length; i++) {
      if (stones >= STARS[i].need) result = STARS[i].star;
    }
    return result;
  }

  function fmt(n) {
    return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00A0');
  }

  /* =======================================================
     3. КАЛЬКУЛЯТОР
     ======================================================= */

  function initCalculator() {
    var widget = document.getElementById('calcWidget');
    if (!widget) return;

    var inputs = {
      budget:  document.getElementById('inpBudget'),
      tome:    document.getElementById('inpTome'),
      grail:   document.getElementById('inpGrail'),
      chapter: document.getElementById('inpChapter')
    };

    var outputs = {
      budget:  document.getElementById('outBudget'),
      tome:    document.getElementById('outTome'),
      grail:   document.getElementById('outGrail'),
      chapter: document.getElementById('outChapter')
    };

    var results = {
      spent:  document.getElementById('resSpent'),
      left:   document.getElementById('resLeft'),
      coins:  document.getElementById('resCoins'),
      pull:   document.getElementById('resPull'),
      pulls:  document.getElementById('resPulls'),
      stones: document.getElementById('resStones'),
      stars:  document.getElementById('resStars'),
      sapph:  document.getElementById('resSapph')
    };

    var msgBox = document.getElementById('calcMsg');

    function render() {
      var budget  = parseInt(inputs.budget.value, 10);
      var tome    = parseInt(inputs.tome.value, 10);
      var grail   = parseInt(inputs.grail.value, 10);
      var chapter = parseInt(inputs.chapter.value, 10);

      outputs.budget.textContent  = budget;
      outputs.tome.textContent    = tome;
      outputs.grail.textContent   = grail;
      outputs.chapter.textContent = chapter;

      var r = simulate(budget, tome, grail, chapter);

      if (!r || !r.ok) {
        var short = r ? r.short : 0;
        results.spent.textContent  = fmt(r ? r.spent : 0);
        results.left.textContent   = '—';
        results.coins.textContent  = '—';
        results.pull.textContent   = '—';
        results.pulls.textContent  = '—';
        results.stones.textContent = '—';
        results.stars.textContent  = '—';
        results.sapph.textContent  = '—';

        msgBox.className = 'calc-msg show err';
        msgBox.textContent =
          'Не хватает ' + fmt(short) + ' кристаллов. ' +
          'Нужно ' + fmt(r ? r.spent : 0) + ', а бюджет ' + fmt(budget) + '. ' +
          'Понизьте уровень реликвий или целевую главу.';
        return;
      }

      results.spent.textContent  = fmt(r.spent);
      results.left.textContent   = fmt(r.left);
      results.coins.textContent  = fmt(r.coins);
      results.pull.textContent   = fmt(r.pullCost);
      results.pulls.textContent  = r.pulls.toFixed(1);
      results.stones.textContent = fmt(r.stones);
      results.sapph.textContent  = fmt(r.sapph);

      var stars = starsFor(r.stones);
      results.stars.textContent = stars > 0 ? ('Алекто ' + stars + '\u2605') : 'меньше 1\u2605';

      // Подсказка: сравниваем с оптимумом при том же бюджете и главе
      var best = findBest(budget, chapter);
      var diff = best.stones - r.stones;

      if (diff <= 20) {
        msgBox.className = 'calc-msg show ok';
        msgBox.textContent =
          'Оптимальная раскладка для главы ' + chapter + ' при бюджете ' + budget +
          ': Том ' + best.tome + ', Грааль ' + best.grail +
          ', Амулет ' + r.amuletLvl + ' (' + fmt(r.amuletCost) + ' кр.). ' +
          'Вы у оптимума.';
      } else {
        msgBox.className = 'calc-msg show err';
        msgBox.textContent =
          'Можно лучше: Том ' + best.tome + ', Грааль ' + best.grail +
          ' даст ~' + fmt(best.stones) + ' осколков (+' + fmt(diff) + ').';
      }
    }

    // Перебор всех комбинаций Тома и Грааля для заданного бюджета и главы
    function findBest(budget, chapter) {
      var best = { stones: -1, tome: 1, grail: 1 };
      for (var t = 1; t <= 15; t++) {
        for (var g = 1; g <= 18; g++) {
          var r = simulate(budget, t, g, chapter);
          if (r && r.ok && r.stones > best.stones) {
            best = { stones: r.stones, tome: t, grail: g, sapph: r.sapph };
          }
        }
      }
      return best;
    }

    Object.keys(inputs).forEach(function (k) {
      inputs[k].addEventListener('input', render);
    });

    // Кнопки-пресеты: data-preset="бюджет,том,грааль,глава"
    widget.querySelectorAll('[data-preset]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var p = btn.getAttribute('data-preset').split(',');
        inputs.budget.value  = p[0];
        inputs.tome.value    = p[1];
        inputs.grail.value   = p[2];
        inputs.chapter.value = p[3];
        render();
      });
    });

    render();
  }

  /* =======================================================
     4. ГРАФИКИ СРАВНЕНИЯ ПЛАНОВ
     ======================================================= */

  var PLANS = [
    { name: 'A · главы 1–2', budget: 465, tome: 6, grail: 4, chapter: 2 },
    { name: 'B · глава 3',   budget: 465, tome: 6, grail: 4, chapter: 3, best: true },
    { name: 'C · глава 4',   budget: 465, tome: 6, grail: 3, chapter: 4 },
    { name: 'D · глава 5',   budget: 465, tome: 5, grail: 3, chapter: 5 }
  ];

  function buildBars(containerId, key, gold) {
    var box = document.getElementById(containerId);
    if (!box) return;

    var data = PLANS.map(function (p) {
      var r = simulate(p.budget, p.tome, p.grail, p.chapter);
      return { name: p.name, value: r && r.ok ? r[key] : 0, best: !!p.best };
    });

    var max = Math.max.apply(null, data.map(function (d) { return d.value; }));

    box.innerHTML = '';
    data.forEach(function (d) {
      var row = document.createElement('div');
      row.className = 'bar-row' + (d.best ? ' is-best' : '');

      var name = document.createElement('div');
      name.className = 'bar-name';
      name.textContent = d.name;

      var track = document.createElement('div');
      track.className = 'bar-track';

      var fill = document.createElement('div');
      fill.className = 'bar-fill' + (gold ? ' gold' : '');
      fill.setAttribute('data-target', max > 0 ? (d.value / max * 100) : 0);
      track.appendChild(fill);

      var val = document.createElement('div');
      val.className = 'bar-val';
      val.textContent = fmt(d.value);

      row.appendChild(name);
      row.appendChild(track);
      row.appendChild(val);
      box.appendChild(row);
    });
  }

  // Полоски заполняются, когда блок появляется в зоне видимости
  function animateBarsOnView() {
    var fills = document.querySelectorAll('.bar-fill');
    if (!fills.length) return;

    if (!('IntersectionObserver' in window)) {
      fills.forEach(function (f) { f.style.width = f.getAttribute('data-target') + '%'; });
      return;
    }

    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.style.width = e.target.getAttribute('data-target') + '%';
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.25 });

    fills.forEach(function (f) { obs.observe(f); });
  }

  /* =======================================================
     5. НАВИГАЦИЯ
     ======================================================= */

  function initNav() {
    var toggle  = document.getElementById('navToggle');
    var sidebar = document.getElementById('sidebar');
    if (!toggle || !sidebar) return;

    toggle.addEventListener('click', function () {
      var open = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    // Закрываем меню после клика по ссылке (на мобильных)
    sidebar.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        if (window.innerWidth <= 1024) {
          sidebar.classList.remove('open');
          toggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    // Клик вне меню закрывает его
    document.addEventListener('click', function (e) {
      if (window.innerWidth > 1024) return;
      if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
        sidebar.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Подсветка активного пункта оглавления
  function initScrollSpy() {
    var links = Array.prototype.slice.call(
      document.querySelectorAll('#toc a[href^="#"]')
    );
    if (!links.length) return;

    var sections = links.map(function (a) {
      return document.querySelector(a.getAttribute('href'));
    }).filter(Boolean);

    function update() {
      var pos = window.scrollY + 120;
      var current = sections[0];

      for (var i = 0; i < sections.length; i++) {
        if (sections[i].offsetTop <= pos) current = sections[i];
      }

      links.forEach(function (a) {
        var on = a.getAttribute('href') === '#' + current.id;
        a.classList.toggle('active', on);
      });
    }

    var ticking = false;
    window.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        update();
        ticking = false;
      });
    }, { passive: true });

    update();
  }

  function initToTop() {
    var btn = document.getElementById('toTop');
    if (!btn) return;

    window.addEventListener('scroll', function () {
      btn.classList.toggle('show', window.scrollY > 600);
    }, { passive: true });

    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* =======================================================
     6. СТАРТ
     ======================================================= */

  function init() {
    initCalculator();
    buildBars('barsStones', 'stones', false);
    buildBars('barsSapph', 'sapph', true);
    animateBarsOnView();
    initNav();
    initScrollSpy();
    initToTop();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Экспорт для отладки в консоли
  window.AlectoCalc = {
    simulate: simulate,
    starsFor: starsFor,
    CHAPTERS: CHAPTERS
  };
})();
