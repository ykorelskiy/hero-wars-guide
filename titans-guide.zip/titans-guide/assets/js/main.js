/* =========================================================
   Титаны Dominion Era — гайд по стихиям, контрпикам, тотемам
   Логика: калькулятор контрпиков, навигация
   ========================================================= */
(function () {
  'use strict';

  /* =======================================================
     1. КРУГ СТИХИЙ
     Источники: support-hwde.nexters.com (Elemental Damage and Armor),
     herowars-olympus.com (Distortion Totem Breakdown)
     ======================================================= */

  var ELEMENTS = {
    water: {
      label: 'Вода',
      beats: ['fire', 'distortion']
    },
    fire: {
      label: 'Огонь',
      beats: ['earth', 'distortion']
    },
    earth: {
      label: 'Земля',
      beats: ['water', 'distortion']
    },
    light: {
      label: 'Свет',
      beats: ['dark']
    },
    dark: {
      label: 'Тьма',
      beats: ['light']
    },
    distortion: {
      label: 'Искажение',
      beats: ['light', 'dark']
    }
  };

  var TAG_CLASS = {
    water: 'tag-water', fire: 'tag-fire', earth: 'tag-earth',
    light: 'tag-light', dark: 'tag-dark', distortion: 'tag-distortion'
  };

  /**
   * Возвращает три списка относительно стихии противника:
   * beats   — чем атаковать (даёт бонус урона против врага)
   * losesTo — что не ставить в атаку (враг получит бонус против них)
   * neutral — стихии без бонусов в любую сторону
   *
   * Единственный источник правды — поле "beats" каждой стихии.
   * Всё остальное (проигрыши, нейтраль) выводится автоматически,
   * поэтому асимметрия вроде Искажения (не мутуальный контрпик)
   * не может рассинхронизироваться.
   */
  function counterInfo(enemyKey) {
    var beats = [];
    var losesTo = [];
    var neutral = [];

    Object.keys(ELEMENTS).forEach(function (key) {
      if (key === enemyKey) return;
      var el = ELEMENTS[key];
      var enemy = ELEMENTS[enemyKey];

      var iBeatEnemy = el.beats.indexOf(enemyKey) !== -1;
      var enemyBeatsMe = enemy.beats.indexOf(key) !== -1;

      if (iBeatEnemy) {
        beats.push(key);
      } else if (enemyBeatsMe) {
        losesTo.push(key);
      } else {
        neutral.push(key);
      }
    });

    return { beats: beats, losesTo: losesTo, neutral: neutral };
  }

  /* =======================================================
     2. КАЛЬКУЛЯТОР КОНТРПИКОВ
     ======================================================= */

  function renderChips(container, keys) {
    container.innerHTML = '';
    if (!keys.length) {
      var empty = document.createElement('span');
      empty.style.cssText = 'font-size:12.5px;color:var(--text-faint);font-style:italic;';
      empty.textContent = 'нет подходящих стихий';
      container.appendChild(empty);
      return;
    }
    keys.forEach(function (key) {
      var chip = document.createElement('span');
      chip.className = 'tag ' + (TAG_CLASS[key] || '');
      chip.textContent = ELEMENTS[key].label;
      container.appendChild(chip);
    });
  }

  function initCounterCalculator() {
    var widget = document.getElementById('counterWidget');
    if (!widget) return;

    var select = document.getElementById('inpEnemy');
    var beatsBox = document.getElementById('counterBeats');
    var losesBox = document.getElementById('counterLoses');
    var neutralBox = document.getElementById('counterNeutral');
    var note = document.getElementById('counterNote');

    function render() {
      var enemyKey = select.value;
      var info = counterInfo(enemyKey);
      var enemyLabel = ELEMENTS[enemyKey].label;

      renderChips(beatsBox, info.beats);
      renderChips(losesBox, info.losesTo);
      renderChips(neutralBox, info.neutral);

      var noteText = 'Против ' + enemyLabel.toLowerCase() + ': ';
      if (info.beats.length) {
        noteText += 'ставьте ' + info.beats.map(function (k) { return ELEMENTS[k].label; }).join(', ') +
          ' — получите бонус урона и (в защите) бонус брони.';
      } else {
        noteText += 'ни одна стихия не получает прямого бонуса урона — бой пойдёт по голым характеристикам.';
      }
      if (enemyKey === 'distortion') {
        noteText += ' Помните: Искажение в защите прикрыто от всей доски, включая себя.';
      }

      note.textContent = noteText;
    }

    select.addEventListener('change', render);
    render();
  }

  /* =======================================================
     3. НАВИГАЦИЯ
     ======================================================= */

  function initNav() {
    var toggle  = document.getElementById('navToggle');
    var sidebar = document.getElementById('sidebar');
    if (!toggle || !sidebar) return;

    toggle.addEventListener('click', function () {
      var open = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    sidebar.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        if (window.innerWidth <= 1024) {
          sidebar.classList.remove('open');
          toggle.setAttribute('aria-expanded', 'false');
        }
      });
    });

    document.addEventListener('click', function (e) {
      if (window.innerWidth > 1024) return;
      if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
        sidebar.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  function initScrollSpy() {
    var links = Array.prototype.slice.call(
      document.querySelectorAll('#toc a[href^="#"]')
    );
    if (!links.length) return;

    var sections = links.map(function (a) {
      return document.querySelector(a.getAttribute('href'));
    }).filter(Boolean);

    function update() {
      var pos = window.scrollY + 120;
      var current = sections[0];

      for (var i = 0; i < sections.length; i++) {
        if (sections[i].offsetTop <= pos) current = sections[i];
      }

      links.forEach(function (a) {
        var on = a.getAttribute('href') === '#' + current.id;
        a.classList.toggle('active', on);
      });
    }

    var ticking = false;
    window.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        update();
        ticking = false;
      });
    }, { passive: true });

    update();
  }

  function initToTop() {
    var btn = document.getElementById('toTop');
    if (!btn) return;

    window.addEventListener('scroll', function () {
      btn.classList.toggle('show', window.scrollY > 600);
    }, { passive: true });

    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* =======================================================
     4. СТАРТ
     ======================================================= */

  function init() {
    initCounterCalculator();
    initNav();
    initScrollSpy();
    initToTop();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Экспорт для отладки в консоли
  window.TitanCounter = {
    ELEMENTS: ELEMENTS,
    counterInfo: counterInfo
  };
})();
